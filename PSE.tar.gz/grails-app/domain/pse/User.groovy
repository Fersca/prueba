package pse

import java.util.Date;


/**
 * El usuario, con sus datos personales y de contacto y su lista de adquisiciones y mensajes
 *
 */
class User {

	String nickname
	String email
	String realName
	String psnAlias
	String avatar
	String password
	Plataform favoritePlataform
	Country country
	String locationName
	String locationFbId
	Boolean admin
	String facebookUserId
	
	//Estas se completan automáticamente por GORM
	Date dateCreated
	Date lastUpdated

	String toString(){
		if (nickname){
			return nickname
		} else {
			return realName
		}
		
	}
	
	//Si no tiene seteado el avatar devuelve uno por default	
	def getAvatar(){
	  if (avatar)
		return avatar
	  else
		return "default_user.jpg"
	}
		
	static hasMany = [adquisitions: Adquisition, desires: Adquisition]
	
    static constraints = {
		nickname()
		nickname(nullable:true)
		psnAlias(nullable:true)
		avatar(nullable:true)
		locationName(nullable:true)
		locationFbId(nullable:true)
    }
	
	def permalink() {
		return '/'+PSE.appName+'/user/'+this.id+'/'+this.nickname.replaceAll(" ","-")
	}
	
}
