package pse

class EsrbController {

    static scaffold = true
	
}
