package pse

class CategoryController {

    static scaffold = true
	
}
