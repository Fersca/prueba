package pse

class CommentController {

    static scaffold = true
}
