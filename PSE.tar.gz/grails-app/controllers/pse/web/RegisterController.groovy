package pse.web

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import pse.Country;
import pse.Plataform;
import pse.User;

import grails.converters.JSON

class RegisterController {

    def index = { 
		
	}
	
	def register = {
				
		String sigreq = params.signed_request
	
		int idx = sigreq.indexOf(".");
		byte[] sig = new Base64(true).decode(sigreq.substring(0, idx).getBytes());
		String rawpayload = sigreq.substring(idx+1);
		String payload = new String(new Base64(true).decode(rawpayload));
		
		def converter = new JSON()
		def json = JSON.parse(payload)
		
		/* check if it is HMAC-SHA256 */
		if (json.algorithm!="HMAC-SHA256") {

			throw new Exception("Unexpected hash algorithm");
		}
		
		//checkSignature(rawpayload, sig);
		
		createUser(json)
		
		chain(controller: 'home', action: 'index')
		
		/*
		if (json.registration){
			render json.registration.email
		} else {
			render json
		}
		*/
	}
	
	def createUser(def json){
		
		User usu = new User()
		usu.email = json.registration.email
		usu.realName= json.registration.name
		
		if (json.registration.password)
			usu.password= json.registration.password
		else 
			usu.password= "Hola"
		
		if (json.registration.location.name)	
			usu.locationName= json.registration.location.name
		
		if (json.registration.location.id)	
			usu.locationFbId= json.registration.location.id
		
		usu.admin=false
		
		Country country = Country.get(1)
		Plataform plataforma = Plataform.get(1)
		
		usu.country = country
		usu.favoritePlataform = plataforma 
		usu.facebookUserId = json.user_id
		
		usu.save(flush:true)
		
		session.user=usu

	}
	
	private void checkSignature(String rawpayload, byte[] sig) throws Exception {
		
		try {
			String secret = "d6a5fe6e37c3a590e7cd763adcb5d33f";
			
			SecretKeySpec secretKeySpec = new SecretKeySpec(secret.getBytes(), "HMAC-SHA256");
			Mac mac = Mac.getInstance("HMAC-SHA256");
			mac.init(secretKeySpec);
			byte[] mysig = mac.doFinal(rawpayload.getBytes());
			if (!Arrays.equals(mysig, sig)) {
				throw new Exception("Non-matching signature for request");
			}
		} catch (NoSuchAlgorithmException e) {
			throw new Exception("Unknown hash algorithm");
		} catch (InvalidKeyException e) {
			throw new Exception("Wrong key for");
		}
				
	}
	
}
