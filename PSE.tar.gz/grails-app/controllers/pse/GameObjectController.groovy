package pse

class GameObjectController {

    static scaffold = true
}
