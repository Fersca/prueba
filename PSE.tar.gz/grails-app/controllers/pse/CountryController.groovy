package pse

class CountryController {

    static scaffold = true
	
}
