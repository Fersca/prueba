package pse

class PlataformController {

    static scaffold = true
}
