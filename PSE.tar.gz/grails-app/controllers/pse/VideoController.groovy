package pse

class VideoController {

    static scaffold = true
}
