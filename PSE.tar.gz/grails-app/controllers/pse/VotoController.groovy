package pse

class VotoController {

    static scaffold = true
}
