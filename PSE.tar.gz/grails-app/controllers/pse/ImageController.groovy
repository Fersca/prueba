package pse

class ImageController {

    static scaffold = true
}
