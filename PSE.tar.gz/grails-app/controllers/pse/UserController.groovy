package pse

class UserController {

    static scaffold = true
}
