package pse

class AdquisitionController {

    static scaffold = true
	
}
