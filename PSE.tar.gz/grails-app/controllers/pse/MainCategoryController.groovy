package pse

class MainCategoryController {

    static scaffold = true
	
}
