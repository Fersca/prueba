package pse

class MessageController {

    static scaffold = true
}
